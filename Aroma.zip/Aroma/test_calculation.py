from calculation import calculate_product_quantity

print(
    calculate_product_quantity(
        product_type_id=1,
        material_type_id=1,
        raw_material_quantity=1000,
        parameter1=2.0,
        parameter2=3.0
    )
)